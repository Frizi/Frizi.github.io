import Vue from 'vue'

export default new Vue({
  data: {
    habits: [
      {
        id: '0',
        name: 'yoga',
        color: "#000",
        track: ['Mon', 'Fri', 'Sat'],
        weeklyTarget: 4
      },
      {
        id: '1',
        name: 'wake up early',
        color: "#000",
        track: ['Mon', 'Tue', 'Sat'],
        weeklyTarget: 4
      },
      {
        id: '2',
        name: 'stay up late',
        color: "#000",
        track: ['Mon', 'Wed', 'Sat', 'Sun'],
        weeklyTarget: 5
      },
      {
        id: '3',
        name: 'cook dinner',
        color: "#000",
        track: ['Mon', 'Thu', 'Sun'],
        weeklyTarget: 7
      },
      {
        id: '4',
        name: 'work',
        color: "#000",
        track: ['Mon', 'Tue', 'Wed', 'Sat'],
        weeklyTarget: 4
      }
    ]
  },

  created () {
    try {
      if (window.localStorage && window.localStorage.serializedHabits) {
        this.habits = JSON.parse(window.localStorage.serializedHabits)
      }
    } catch (e) {
      // ignore localstorage read error, just leave initial data untouched
    }
  },

  watch: {
    habits: {
      handler (updatedHabits) {
        try {
          if (window.localStorage) {
            window.localStorage.setItem('serializedHabits', JSON.stringify(updatedHabits))
          }
        } catch (e) {
          // ignore localstorage write error, can happen in safari private mode
        }
      },
      deep: true
    }
  },

  methods: {
    addHabit (habit) {
      this.habits.push(habit)
    },

    removeHabit (habit) {
      this.habits = this.habits.filter(h => h !== habit)
    },

    editHabit (id, newHabit) {
      this.habits = this.habits.map(h => h.id === id ? newHabit : h)
    }
  }
})
