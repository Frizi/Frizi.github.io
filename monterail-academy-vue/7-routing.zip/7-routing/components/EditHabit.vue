<template>
  <page-layout>
    <template slot="header">
      <h1 layout="row center gutter">
        <router-link to="/">
          <el-button>
            <i class="el-icon-back"></i>
          </el-button>
        </router-link>
        <span>Editing habit {{ originalHabit.name }}</span>
      </h1>
    </template>
    <template slot="content">
      <Well>
        <HabitForm v-if="editedHabit" :habit="editedHabit" @submit="submitForm"/>
      </Well>
    </template>
  </page-layout>
</template>

<script>
import PageLayout from './PageLayout'
import HabitForm from './HabitForm'
import Well from './Well'
import store from '../store'
export default {
  components: {
    PageLayout,
    Well,
    HabitForm
  },
  data () {
    return {
      editedHabit: null
    }
  },

  computed: {
    originalHabit () {
      return store.habits.find(h => h.id === this.$route.params.id)
    }
  },

  created () {
    if (!this.originalHabit) {
      this.$router.replace({name: 'Home'})
      return
    }
    this.editedHabit = { ...this.originalHabit }
  },

  methods: {
    submitForm () {
      store.editHabit(this.$route.params.id, this.editedHabit)
      this.$router.push({name: 'Home'})
    }
  }
}
</script>
