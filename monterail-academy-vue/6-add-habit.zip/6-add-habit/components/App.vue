<template>
  <Container>
    <h1>Your habits</h1>
    <div layout="column gutter">
      <div v-for="habit in habits" :key="habit.id">
        <HabitCard :habit="habit" @remove="removeHabit(habit)" />
      </div>
      <habit-form v-if="editedHabit" :habit="editedHabit" @submit="submitForm" />
    </div>
  </Container>
</template>

<script>
import Container from './Container'
import HabitCard from './HabitCard'
import HabitForm from './HabitForm'
import uuid from 'uuid/v4'

export default {
  components: {
    Container,
    HabitCard,
    HabitForm
  },
  methods: {
    submitForm () {
      this.habits = this.habits.concat(this.editedHabit)
      this.clearEditedHabit()
    },

    removeHabit (habit) {
      this.habits = this.habits.filter(h => h !== habit)
    },

    clearEditedHabit () {
      this.editedHabit = {
        id: uuid(),
        name: '',
        track: [],
        weeklyTarget: 5
      }
    }
  },

  mounted () {
    this.clearEditedHabit()
  },

  data () {
    return {
      editedHabit: null,
      habits: [
        {
          id: 1,
          name: 'wake up early',
          track: ['Mon', 'Tue', 'Sat'],
          weeklyTarget: 4
        },
        {
          id: 3,
          name: 'cook dinner',
          track: ['Mon', 'Thu', 'Sun'],
          weeklyTarget: 7
        },
      ]
    }
  }
}
</script>
