<template>
  <Well>
    <el-form label-width="120px" @submit.native.prevent="$emit('submit', habit)">
      <el-form-item label="Habit name">
        <el-input type="text" v-model="habit.name"/>
      </el-form-item>
      <el-form-item label="Weekly target">
        <el-input-number :max="7" :min="1" v-model="habit.weeklyTarget"></el-input-number>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" native-type="submit">Add</el-button>
      </el-form-item>
    </el-form>
  </Well>
</template>

<script>
import Well from './Well'
export default {
  components: {
    Well
  },
  props: {
    habit: Object
  }
}
</script>
