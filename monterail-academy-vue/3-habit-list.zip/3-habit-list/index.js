import Vue from 'vue'
import './layout.css'

import App from './components/App'

new Vue({
  el: '#app',
  render: (h) => h(App)
})
