<template>
  <div layout="column center">
    <div class="container" layout="column gutter">
      <h1>Your habits</h1>
      <div layout="column gutter">
        <div v-for="habit in habits" :key="habit.id" class="habit-card">
          <div layout="row center gutter">
            <span flex>{{ habit.name }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      habits: [
        {
          id: 0,
          name: 'yoga',
          color: "#000",
          track: ['Mon', 'Fri', 'Sat'],
          weeklyTarget: 4
        },
        {
          id: 1,
          name: 'wake up early',
          color: "#000",
          track: ['Mon', 'Tue', 'Sat'],
          weeklyTarget: 4
        },
        {
          id: 2,
          name: 'stay up late',
          color: "#000",
          track: ['Mon', 'Wed', 'Sat', 'Sun'],
          weeklyTarget: 5
        },
        {
          id: 3,
          name: 'cook dinner',
          color: "#000",
          track: ['Mon', 'Thu', 'Sun'],
          weeklyTarget: 7
        },
        {
          id: 4,
          name: 'work',
          color: "#000",
          track: ['Mon', 'Tue', 'Wed', 'Sat'],
          weeklyTarget: 4
        }
      ]
    }
  }
}
</script>

<style>
  @import url(https://fonts.googleapis.com/icon?family=Material+Icons);

  .container {
    width: 100%;
    max-width: 700px;
  }

  .habit-card {
    border-radius: 3px;
    margin: 4px;
    padding: 4px;
    background: #abc;
  }
</style>
