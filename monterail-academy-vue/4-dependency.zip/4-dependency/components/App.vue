<template>
  <div layout="column center">
    <div class="container">
      <h1>Your habits</h1>
      <div layout="column gutter">
        <div
          v-for="habit in habits"
          :key="habit.id"
          class="habit-card"
        >
          <div class="well">
            <div layout="row center gutter">
              <span>
                {{ Math.min(100, (habit.track.length / habit.weeklyTarget) * 100).toFixed(0) }}%
                ({{ habit.track.length }}/{{habit.weeklyTarget }})
              </span>
              <span flex>{{ habit.name }}</span>
              <el-checkbox-group layout="row" v-model="habit.track">
                <div v-for="day in weekDays" :key="day" class="checkbox">
                  <el-checkbox :label="day" />
                </div>
              </el-checkbox-group>
              <el-button><i class="el-icon-delete"></i></el-button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data () {
    return {
      weekDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      habits: [
        {
          id: 0,
          name: 'yoga',
          color: "#000",
          track: ['Mon', 'Fri', 'Sat'],
          weeklyTarget: 4
        },
        {
          id: 1,
          name: 'wake up early',
          color: "#000",
          track: ['Mon', 'Tue', 'Sat'],
          weeklyTarget: 4
        },
        {
          id: 2,
          name: 'stay up late',
          color: "#000",
          track: ['Mon', 'Wed', 'Sat', 'Sun'],
          weeklyTarget: 5
        },
        {
          id: 3,
          name: 'cook dinner',
          color: "#000",
          track: ['Mon', 'Thu', 'Sun'],
          weeklyTarget: 7
        },
        {
          id: 4,
          name: 'work',
          color: "#000",
          track: ['Mon', 'Tue', 'Wed', 'Sat'],
          weeklyTarget: 4
        }
      ]
    }
  }
}
</script>

<style>
  @import url(https://fonts.googleapis.com/icon?family=Material+Icons);

  body {
    overflow-x: hidden;
  }

  .well {
    border-bottom: 1px solid #e6ebf5;
    background-color: #fff;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
    padding: 10px;
    border-radius: 4px;
  }

  .container {
    width: 100%;
    max-width: 800px;
  }

  .habit-card {
    border-radius: 3px;
  }
  .checkbox + .checkbox {
    padding-left: 16px;
  }

</style>
