<template>
  <Container>
    <h1>Your habits</h1>
    <div layout="column gutter">
      <div
        v-for="habit in habits"
        :key="habit.id"
        class="habit-card"
      >
        <HabitCard :habit="habit" />
      </div>
    </div>
  </Container>
</template>

<script>
import Container from './Container'
import HabitCard from './HabitCard'
export default {
  components: {
    Container,
    HabitCard
  },

  data () {
    return {
      editedHabit: {
        id: 0,
        color: '#000',
        name: '',
        track: [],
        weeklyTarget: 5
      },
      habits: [
        {
          id: 0,
          name: 'yoga',
          color: "#000",
          track: ['Mon', 'Fri', 'Sat'],
          weeklyTarget: 4
        },
        {
          id: 1,
          name: 'wake up early',
          color: "#000",
          track: ['Mon', 'Tue', 'Sat'],
          weeklyTarget: 4
        },
        {
          id: 2,
          name: 'stay up late',
          color: "#000",
          track: ['Mon', 'Wed', 'Sat', 'Sun'],
          weeklyTarget: 5
        },
        {
          id: 3,
          name: 'cook dinner',
          color: "#000",
          track: ['Mon', 'Thu', 'Sun'],
          weeklyTarget: 7
        },
        {
          id: 4,
          name: 'work',
          color: "#000",
          track: ['Mon', 'Tue', 'Wed', 'Sat'],
          weeklyTarget: 4
        }
      ]
    }
  }
}
</script>
