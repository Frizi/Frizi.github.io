<template>
  <div>
    <h1>{{ greetings }} World!</h1>
    <input type="text" v-model="greetings">
  </div>
</template>

<script>
export default {
  name: 'App',
  data () {
    return {
      greetings: 'Hello, Vue'
    }
  }
}
</script>
